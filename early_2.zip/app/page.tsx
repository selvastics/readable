"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Upload,
  Play,
  Pause,
  RotateCcw,
  Square,
  FileText,
  Clock,
  Target,
  TrendingUp,
  Brain,
  CheckCircle,
  BarChart3,
  Download,
  BookOpen,
  Award,
  Lightbulb,
} from "lucide-react"
import { cn } from "@/lib/utils"

interface ReadingStats {
  wordsRead: number
  timeElapsed: number
  currentWPM: number
  averageWPM: number
  accuracy: number
  comprehensionScore: number
  sessionsCompleted: number
}

interface ReaderSettings {
  wpm: number
  pauseAtPunctuation: boolean
  highlightMode: boolean
  fontSize: number
  comprehensionLevel: "basic" | "intermediate" | "advanced"
}

interface Question {
  id: string
  type: "multiple-choice" | "true-false" | "short-answer"
  question: string
  options?: string[]
  correctAnswer: string
  explanation?: string
  difficulty: "easy" | "medium" | "hard"
}

interface TestResult {
  questionId: string
  userAnswer: string
  isCorrect: boolean
  timeSpent: number
}

interface StudySession {
  id: string
  timestamp: number
  textLength: number
  readingTime: number
  wpm: number
  comprehensionScore: number
  questionsAnswered: number
  correctAnswers: number
  difficulty: string
}

export default function ReablePlatform() {
  const [text, setText] = useState("")
  const [words, setWords] = useState<string[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isReading, setIsReading] = useState(false)
  const [showComprehensionTest, setShowComprehensionTest] = useState(false)
  const [currentView, setCurrentView] = useState<"reader" | "test" | "analytics">("reader")

  const [settings, setSettings] = useState<ReaderSettings>({
    wpm: 300,
    pauseAtPunctuation: true,
    highlightMode: false,
    fontSize: 48,
    comprehensionLevel: "basic",
  })

  const [stats, setStats] = useState<ReadingStats>({
    wordsRead: 0,
    timeElapsed: 0,
    currentWPM: 300,
    averageWPM: 0,
    accuracy: 100,
    comprehensionScore: 0,
    sessionsCompleted: 0,
  })

  const [questions, setQuestions] = useState<Question[]>([])
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({})
  const [testResults, setTestResults] = useState<TestResult[]>([])
  const [studySessions, setStudySessions] = useState<StudySession[]>([])
  const [showResults, setShowResults] = useState(false)

  const [startTime, setStartTime] = useState<number | null>(null)
  const [questionStartTime, setQuestionStartTime] = useState<number | null>(null)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Generate comprehension questions based on text
  const generateQuestions = useCallback(
    (inputText: string): Question[] => {
      const sentences = inputText.split(/[.!?]+/).filter((s) => s.trim().length > 10)
      const generatedQuestions: Question[] = []

      // Generate different types of questions based on comprehension level
      const questionCount =
        settings.comprehensionLevel === "basic" ? 3 : settings.comprehensionLevel === "intermediate" ? 5 : 7

      for (let i = 0; i < Math.min(questionCount, sentences.length); i++) {
        const sentence = sentences[i].trim()

        if (i % 3 === 0) {
          // Multiple choice question
          generatedQuestions.push({
            id: `mc-${i}`,
            type: "multiple-choice",
            question: `Based on the text, which statement is most accurate about: "${sentence.substring(0, 50)}..."?`,
            options: [
              "This information was clearly stated in the text",
              "This information was implied but not directly stated",
              "This information contradicts what was in the text",
              "This information was not mentioned in the text",
            ],
            correctAnswer: "This information was clearly stated in the text",
            difficulty: settings.comprehensionLevel === "basic" ? "easy" : "medium",
          })
        } else if (i % 3 === 1) {
          // True/False question
          generatedQuestions.push({
            id: `tf-${i}`,
            type: "true-false",
            question: `True or False: The text mentioned "${sentence.split(" ").slice(0, 8).join(" ")}..."`,
            options: ["True", "False"],
            correctAnswer: "True",
            difficulty: "easy",
          })
        } else {
          // Short answer question
          generatedQuestions.push({
            id: `sa-${i}`,
            type: "short-answer",
            question: `In your own words, summarize the main point of this section: "${sentence.substring(0, 100)}..."`,
            correctAnswer: sentence.substring(0, 50),
            difficulty: settings.comprehensionLevel === "advanced" ? "hard" : "medium",
          })
        }
      }

      return generatedQuestions
    },
    [settings.comprehensionLevel],
  )

  const processText = useCallback((inputText: string): string[] => {
    return inputText
      .replace(/\s+/g, " ")
      .trim()
      .split(" ")
      .filter((word) => word.length > 0)
  }, [])

  const handleTextChange = (value: string) => {
    setText(value)
    if (value.trim()) {
      setWords(processText(value))
      setQuestions(generateQuestions(value))
    }
  }

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return

    try {
      let content = ""
      if (file.type === "text/plain") {
        content = await file.text()
      } else {
        throw new Error("Only text files are supported in this demo")
      }

      setText(content)
      setWords(processText(content))
      setQuestions(generateQuestions(content))
    } catch (error) {
      console.error("Error reading file:", error)
    }
  }

  const startReading = () => {
    if (words.length === 0) return

    setIsReading(true)
    setCurrentIndex(0)
    setStartTime(Date.now())
    setStats((prev) => ({ ...prev, wordsRead: 0, timeElapsed: 0 }))
    playReading()
  }

  const playReading = () => {
    if (currentIndex >= words.length) {
      completeReading()
      return
    }

    setIsPlaying(true)

    const displayNextWord = () => {
      if (!isPlaying || currentIndex >= words.length) {
        if (currentIndex >= words.length) {
          completeReading()
        }
        return
      }

      setCurrentIndex((prev) => {
        const newIndex = prev + 1
        setStats((prevStats) => ({
          ...prevStats,
          wordsRead: newIndex,
          timeElapsed: startTime ? Math.floor((Date.now() - startTime) / 1000) : 0,
        }))
        return newIndex
      })

      let delay = 60000 / settings.wpm

      if (settings.pauseAtPunctuation && /[.!?]$/.test(words[currentIndex])) {
        delay *= 1.5
      }

      intervalRef.current = setTimeout(displayNextWord, delay)
    }

    displayNextWord()
  }

  const completeReading = () => {
    pauseReading()
    setIsReading(false)
    setShowComprehensionTest(true)
    setCurrentQuestionIndex(0)
    setQuestionStartTime(Date.now())
  }

  const pauseReading = () => {
    setIsPlaying(false)
    if (intervalRef.current) {
      clearTimeout(intervalRef.current)
    }
  }

  const resetReading = () => {
    pauseReading()
    setCurrentIndex(0)
    setStartTime(Date.now())
    setStats((prev) => ({ ...prev, wordsRead: 0, timeElapsed: 0 }))
  }

  const stopReading = () => {
    pauseReading()
    setIsReading(false)
    setCurrentIndex(0)
    setShowComprehensionTest(false)
  }

  const handleAnswerChange = (questionId: string, answer: string) => {
    setUserAnswers((prev) => ({ ...prev, [questionId]: answer }))
  }

  const submitAnswer = () => {
    const currentQuestion = questions[currentQuestionIndex]
    const userAnswer = userAnswers[currentQuestion.id] || ""
    const isCorrect = userAnswer.toLowerCase().trim() === currentQuestion.correctAnswer.toLowerCase().trim()

    const timeSpent = questionStartTime ? Date.now() - questionStartTime : 0

    setTestResults((prev) => [
      ...prev,
      {
        questionId: currentQuestion.id,
        userAnswer,
        isCorrect,
        timeSpent,
      },
    ])

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1)
      setQuestionStartTime(Date.now())
    } else {
      completeTest()
    }
  }

  const completeTest = () => {
    const correctAnswers = testResults.filter((r) => r.isCorrect).length + 1 // +1 for current answer
    const totalQuestions = questions.length
    const comprehensionScore = Math.round((correctAnswers / totalQuestions) * 100)

    const session: StudySession = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      textLength: words.length,
      readingTime: stats.timeElapsed,
      wpm: stats.averageWPM || settings.wpm,
      comprehensionScore,
      questionsAnswered: totalQuestions,
      correctAnswers,
      difficulty: settings.comprehensionLevel,
    }

    setStudySessions((prev) => [...prev, session])
    setStats((prev) => ({
      ...prev,
      comprehensionScore,
      sessionsCompleted: prev.sessionsCompleted + 1,
    }))

    setShowResults(true)
    setShowComprehensionTest(false)
  }

  const resetTest = () => {
    setShowComprehensionTest(false)
    setShowResults(false)
    setCurrentQuestionIndex(0)
    setUserAnswers({})
    setTestResults([])
    setCurrentView("reader")
  }

  const exportStudyData = () => {
    const data = {
      sessions: studySessions,
      overallStats: stats,
      settings: settings,
      exportDate: new Date().toISOString(),
    }

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `reable-study-data-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  const togglePlayPause = () => {
    if (isPlaying) {
      pauseReading()
    } else {
      playReading()
    }
  }

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (!isReading) return

      if (event.code === "Space") {
        event.preventDefault()
        togglePlayPause()
      } else if (event.code === "Escape") {
        stopReading()
      } else if (event.code === "KeyR") {
        resetReading()
      }
    }

    document.addEventListener("keydown", handleKeyPress)
    return () => document.removeEventListener("keydown", handleKeyPress)
  }, [isReading, isPlaying])

  // Update stats
  useEffect(() => {
    if (startTime && stats.timeElapsed > 0) {
      const averageWPM = Math.round((stats.wordsRead / stats.timeElapsed) * 60)
      setStats((prev) => ({ ...prev, averageWPM, currentWPM: settings.wpm }))
    }
  }, [stats.wordsRead, stats.timeElapsed, startTime, settings.wpm])

  const progress = words.length > 0 ? (currentIndex / words.length) * 100 : 0
  const currentWord = words[currentIndex] || "Ready..."

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  const speedPresets = [200, 300, 400, 500, 600, 800]

  // Comprehension Test Interface
  if (showComprehensionTest && questions.length > 0) {
    const currentQuestion = questions[currentQuestionIndex]

    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
        <div className="max-w-3xl mx-auto">
          <Card className="mb-6">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Brain className="w-6 h-6 text-primary" />
                Comprehension Test
              </CardTitle>
              <CardDescription>
                Question {currentQuestionIndex + 1} of {questions.length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={((currentQuestionIndex + 1) / questions.length) * 100} className="mb-6" />

              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">{currentQuestion.question}</h3>

                  {currentQuestion.type === "multiple-choice" && (
                    <RadioGroup
                      value={userAnswers[currentQuestion.id] || ""}
                      onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
                    >
                      {currentQuestion.options?.map((option, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <RadioGroupItem value={option} id={`option-${index}`} />
                          <Label htmlFor={`option-${index}`}>{option}</Label>
                        </div>
                      ))}
                    </RadioGroup>
                  )}

                  {currentQuestion.type === "true-false" && (
                    <RadioGroup
                      value={userAnswers[currentQuestion.id] || ""}
                      onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="True" id="true" />
                        <Label htmlFor="true">True</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="False" id="false" />
                        <Label htmlFor="false">False</Label>
                      </div>
                    </RadioGroup>
                  )}

                  {currentQuestion.type === "short-answer" && (
                    <Textarea
                      placeholder="Enter your answer here..."
                      value={userAnswers[currentQuestion.id] || ""}
                      onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                      className="min-h-[100px]"
                    />
                  )}
                </div>

                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
                    disabled={currentQuestionIndex === 0}
                  >
                    Previous
                  </Button>

                  <Button onClick={submitAnswer} disabled={!userAnswers[currentQuestion.id]}>
                    {currentQuestionIndex === questions.length - 1 ? "Complete Test" : "Next Question"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Results Interface
  if (showResults) {
    const lastSession = studySessions[studySessions.length - 1]

    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 p-4">
        <div className="max-w-4xl mx-auto">
          <Card className="mb-6">
            <CardHeader className="text-center">
              <CardTitle className="flex items-center justify-center gap-2">
                <Award className="w-6 h-6 text-primary" />
                Session Complete!
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">{lastSession?.comprehensionScore}%</div>
                  <p className="text-sm text-muted-foreground">Comprehension Score</p>
                </div>

                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">{lastSession?.wpm}</div>
                  <p className="text-sm text-muted-foreground">Average WPM</p>
                </div>

                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">
                    {lastSession?.correctAnswers}/{lastSession?.questionsAnswered}
                  </div>
                  <p className="text-sm text-muted-foreground">Correct Answers</p>
                </div>
              </div>

              <div className="space-y-4">
                {lastSession && lastSession.comprehensionScore >= 80 && (
                  <Alert>
                    <CheckCircle className="h-4 w-4" />
                    <AlertDescription>
                      Excellent comprehension! You're ready for more advanced reading speeds.
                    </AlertDescription>
                  </Alert>
                )}

                {lastSession && lastSession.comprehensionScore < 60 && (
                  <Alert>
                    <Lightbulb className="h-4 w-4" />
                    <AlertDescription>
                      Consider reducing reading speed to improve comprehension. Focus on understanding over speed.
                    </AlertDescription>
                  </Alert>
                )}
              </div>

              <div className="flex justify-center gap-4 mt-6">
                <Button onClick={resetTest}>Start New Session</Button>
                <Button variant="outline" onClick={() => setCurrentView("analytics")}>
                  View Analytics
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  // Main Interface with Tabs
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2">Reable</h1>
          <p className="text-xl text-muted-foreground">Professional Speed Reading & Comprehension Platform</p>
          <p className="text-sm text-muted-foreground mt-2">
            Advanced reading training with empirical study capabilities
          </p>
        </div>

        <Tabs value={currentView} onValueChange={(value) => setCurrentView(value as any)} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reader" className="flex items-center gap-2">
              <BookOpen className="w-4 h-4" />
              Speed Reader
            </TabsTrigger>
            <TabsTrigger value="test" className="flex items-center gap-2">
              <Brain className="w-4 h-4" />
              Comprehension Test
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Study Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reader" className="space-y-6">
            {isReading ? (
              // Reading Interface (same as before)
              <div>
                <div className="mb-6">
                  <Progress value={progress} className="h-2" />
                </div>

                <Card className="mb-6">
                  <CardContent className="pt-12 pb-12">
                    <div className="text-center">
                      <div
                        className={cn(
                          "font-mono font-bold text-primary mb-8 transition-all duration-200",
                          settings.highlightMode && "bg-primary/10 px-4 py-2 rounded-lg",
                        )}
                        style={{ fontSize: `${settings.fontSize}px` }}
                      >
                        {currentWord}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                        <div className="text-center">
                          <div className="flex items-center justify-center mb-2">
                            <Target className="w-5 h-5 mr-2 text-primary" />
                            <span className="text-2xl font-bold text-primary">{stats.currentWPM}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Current WPM</p>
                        </div>

                        <div className="text-center">
                          <div className="flex items-center justify-center mb-2">
                            <TrendingUp className="w-5 h-5 mr-2 text-primary" />
                            <span className="text-2xl font-bold text-primary">{stats.averageWPM}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Average WPM</p>
                        </div>

                        <div className="text-center">
                          <div className="flex items-center justify-center mb-2">
                            <FileText className="w-5 h-5 mr-2 text-primary" />
                            <span className="text-2xl font-bold text-primary">{stats.wordsRead}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Words Read</p>
                        </div>

                        <div className="text-center">
                          <div className="flex items-center justify-center mb-2">
                            <Clock className="w-5 h-5 mr-2 text-primary" />
                            <span className="text-2xl font-bold text-primary">{formatTime(stats.timeElapsed)}</span>
                          </div>
                          <p className="text-sm text-muted-foreground">Time Elapsed</p>
                        </div>
                      </div>

                      <div className="flex justify-center gap-3">
                        <Button onClick={togglePlayPause} size="lg" className="px-8">
                          {isPlaying ? <Pause className="w-5 h-5 mr-2" /> : <Play className="w-5 h-5 mr-2" />}
                          {isPlaying ? "Pause" : "Play"}
                        </Button>
                        <Button onClick={resetReading} variant="outline" size="lg">
                          <RotateCcw className="w-5 h-5 mr-2" />
                          Reset
                        </Button>
                        <Button onClick={stopReading} variant="outline" size="lg">
                          <Square className="w-5 h-5 mr-2" />
                          Stop
                        </Button>
                      </div>

                      <div className="mt-6 text-sm text-muted-foreground">
                        <p>
                          Press <Badge variant="outline">Space</Badge> to play/pause •{" "}
                          <Badge variant="outline">Esc</Badge> to stop • <Badge variant="outline">R</Badge> to reset
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              // Setup Interface
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Text Input</CardTitle>
                    <CardDescription>Enter or upload your text to begin speed reading</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      placeholder="Paste your text here..."
                      value={text}
                      onChange={(e) => handleTextChange(e.target.value)}
                      className="min-h-[120px] resize-none"
                    />

                    <Separator />

                    <div className="text-center">
                      <input
                        ref={fileInputRef}
                        type="file"
                        accept=".txt,.pdf,.doc,.docx"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="w-full">
                        <Upload className="w-4 h-4 mr-2" />
                        Upload File
                      </Button>
                      <p className="text-xs text-muted-foreground mt-2">Supports TXT, PDF, DOC, DOCX files</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Reading Settings</CardTitle>
                    <CardDescription>Customize your reading experience</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <Label className="text-sm font-medium mb-3 block">Reading Speed (WPM)</Label>
                      <div className="flex flex-wrap gap-2 mb-3">
                        {speedPresets.map((speed) => (
                          <Button
                            key={speed}
                            variant={settings.wpm === speed ? "default" : "outline"}
                            size="sm"
                            onClick={() => setSettings((prev) => ({ ...prev, wpm: speed }))}
                          >
                            {speed}
                          </Button>
                        ))}
                      </div>
                      <Input
                        type="number"
                        placeholder="Custom WPM"
                        min={50}
                        max={1000}
                        value={settings.wpm}
                        onChange={(e) =>
                          setSettings((prev) => ({ ...prev, wpm: Number.parseInt(e.target.value) || 300 }))
                        }
                      />
                    </div>

                    <div>
                      <Label className="text-sm font-medium mb-3 block">Comprehension Level</Label>
                      <RadioGroup
                        value={settings.comprehensionLevel}
                        onValueChange={(value) =>
                          setSettings((prev) => ({ ...prev, comprehensionLevel: value as any }))
                        }
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="basic" id="basic" />
                          <Label htmlFor="basic">Basic (3 questions)</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="intermediate" id="intermediate" />
                          <Label htmlFor="intermediate">Intermediate (5 questions)</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="advanced" id="advanced" />
                          <Label htmlFor="advanced">Advanced (7 questions)</Label>
                        </div>
                      </RadioGroup>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="punctuation"
                          checked={settings.pauseAtPunctuation}
                          onCheckedChange={(checked) =>
                            setSettings((prev) => ({ ...prev, pauseAtPunctuation: checked as boolean }))
                          }
                        />
                        <Label htmlFor="punctuation" className="text-sm">
                          Pause at punctuation
                        </Label>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="highlight"
                          checked={settings.highlightMode}
                          onCheckedChange={(checked) =>
                            setSettings((prev) => ({ ...prev, highlightMode: checked as boolean }))
                          }
                        />
                        <Label htmlFor="highlight" className="text-sm">
                          Highlight mode
                        </Label>
                      </div>
                    </div>

                    <div>
                      <Label className="text-sm font-medium mb-2 block">Font Size</Label>
                      <Input
                        type="range"
                        min={24}
                        max={72}
                        value={settings.fontSize}
                        onChange={(e) =>
                          setSettings((prev) => ({ ...prev, fontSize: Number.parseInt(e.target.value) }))
                        }
                        className="w-full"
                      />
                      <div className="text-xs text-muted-foreground mt-1">{settings.fontSize}px</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {!isReading && (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <Button
                      onClick={startReading}
                      disabled={words.length === 0}
                      size="lg"
                      className="px-12 py-6 text-lg"
                    >
                      <Play className="w-6 h-6 mr-3" />
                      Start Reading Session
                    </Button>

                    {words.length > 0 && (
                      <div className="mt-4 space-y-2">
                        <p className="text-sm text-muted-foreground">
                          Ready to read {words.length} words at {settings.wpm} WPM
                          <br />
                          Estimated time: {Math.ceil((words.length / settings.wpm) * 60)} seconds
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Comprehension test will follow ({settings.comprehensionLevel} level -{" "}
                          {settings.comprehensionLevel === "basic"
                            ? "3"
                            : settings.comprehensionLevel === "intermediate"
                              ? "5"
                              : "7"}{" "}
                          questions)
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="test" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  Comprehension Testing
                </CardTitle>
                <CardDescription>
                  Test your reading comprehension with automatically generated questions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {questions.length === 0 ? (
                  <div className="text-center py-8">
                    <Brain className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">Complete a reading session to access comprehension testing</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Alert>
                      <Lightbulb className="h-4 w-4" />
                      <AlertDescription>
                        {questions.length} questions ready based on your last reading session (
                        {settings.comprehensionLevel} level)
                      </AlertDescription>
                    </Alert>

                    <Button onClick={() => setShowComprehensionTest(true)} className="w-full">
                      Start Comprehension Test
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">{stats.sessionsCompleted}</div>
                    <p className="text-sm text-muted-foreground">Sessions Completed</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {studySessions.length > 0
                        ? Math.round(studySessions.reduce((acc, s) => acc + s.wpm, 0) / studySessions.length)
                        : 0}
                    </div>
                    <p className="text-sm text-muted-foreground">Average WPM</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {studySessions.length > 0
                        ? Math.round(
                            studySessions.reduce((acc, s) => acc + s.comprehensionScore, 0) / studySessions.length,
                          )
                        : 0}
                      %
                    </div>
                    <p className="text-sm text-muted-foreground">Avg Comprehension</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {studySessions.reduce((acc, s) => acc + s.readingTime, 0)}s
                    </div>
                    <p className="text-sm text-muted-foreground">Total Reading Time</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5" />
                    Study Sessions
                  </span>
                  <Button onClick={exportStudyData} variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Export Data
                  </Button>
                </CardTitle>
                <CardDescription>Detailed analytics for empirical research and performance tracking</CardDescription>
              </CardHeader>
              <CardContent>
                {studySessions.length === 0 ? (
                  <div className="text-center py-8">
                    <BarChart3 className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">
                      No study sessions yet. Complete reading sessions to see analytics.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {studySessions
                      .slice(-5)
                      .reverse()
                      .map((session, index) => (
                        <div key={session.id} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <h4 className="font-semibold">Session {studySessions.length - index}</h4>
                              <p className="text-sm text-muted-foreground">
                                {new Date(session.timestamp).toLocaleString()}
                              </p>
                            </div>
                            <Badge
                              variant={
                                session.comprehensionScore >= 80
                                  ? "default"
                                  : session.comprehensionScore >= 60
                                    ? "secondary"
                                    : "destructive"
                              }
                            >
                              {session.comprehensionScore}% Comprehension
                            </Badge>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">WPM:</span> {session.wpm}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Words:</span> {session.textLength}
                            </div>
                            <div>
                              <span className="text-muted-foreground">Time:</span> {session.readingTime}s
                            </div>
                            <div>
                              <span className="text-muted-foreground">Difficulty:</span> {session.difficulty}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

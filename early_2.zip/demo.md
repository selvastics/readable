# Demo

To see the speed reader in action:

1. Open `index.html` in your browser
2. Paste some text or upload a file
3. Set your reading speed
4. Click "Start Reading"

## Screenshots

*Screenshots will be added here*

## Quick Demo Text

Try this sample text:

```
The quick brown fox jumps over the lazy dog. This is a simple sentence to test your reading speed. As you practice, you'll find yourself reading faster and faster. The key is to focus on one word at a time without subvocalizing. Keep your eyes centered on each word as it appears. With regular practice, you can significantly improve your reading speed while maintaining good comprehension.

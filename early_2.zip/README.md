# Speed Reader

A simple, fast web app for speed reading training. Focus on one word at a time to improve your reading speed.

## Features

- **Simple interface** - Clean, minimal design
- **Multiple input methods** - Paste text or upload files (TXT, PDF, DOC, DOCX)
- **Adjustable speed** - From 50 to 1000 words per minute
- **Progress tracking** - See your reading progress in real-time
- **Keyboard shortcuts** - Space to play/pause, Escape to stop
- **Mobile friendly** - Works on all devices

## How to Use

1. **Add text** - Paste text in the box or upload a file
2. **Set speed** - Choose from presets or enter custom WPM
3. **Start reading** - Click "Start Reading" to begin
4. **Control** - Use buttons or keyboard shortcuts (Space/Escape)

## Quick Start

Open `index.html` in your browser. No installation needed.

## File Support

- **TXT** - Plain text files
- **PDF** - Text extraction from PDFs
- **DOC/DOCX** - Microsoft Word documents

## Tips

- Start at 200-300 WPM if you're new to speed reading
- Use "Pause at punctuation" for better comprehension
- Gradually increase speed as you get comfortable

## Browser Support

Works in all modern browsers. No extensions or plugins required.

## License

MIT - Feel free to use, modify, and share.
